--
-- PostgreSQL database dump
--

\restrict Yin8Vo3QZBIzTWD2PeicHYlzUcvLq1irhCjuMJD3a64tP4P7v8eQPiYkK3f2FZv

-- Dumped from database version 16.13 (Debian 16.13-1.pgdg13+1)
-- Dumped by pg_dump version 16.13 (Debian 16.13-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: action_text_rich_texts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.action_text_rich_texts (
    id bigint NOT NULL,
    name character varying NOT NULL,
    body text,
    record_type character varying NOT NULL,
    record_id bigint NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.action_text_rich_texts OWNER TO postgres;

--
-- Name: action_text_rich_texts_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.action_text_rich_texts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.action_text_rich_texts_id_seq OWNER TO postgres;

--
-- Name: action_text_rich_texts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.action_text_rich_texts_id_seq OWNED BY public.action_text_rich_texts.id;


--
-- Name: active_storage_attachments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.active_storage_attachments (
    id bigint NOT NULL,
    name character varying NOT NULL,
    record_type character varying NOT NULL,
    record_id bigint NOT NULL,
    blob_id bigint NOT NULL,
    created_at timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.active_storage_attachments OWNER TO postgres;

--
-- Name: active_storage_attachments_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.active_storage_attachments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.active_storage_attachments_id_seq OWNER TO postgres;

--
-- Name: active_storage_attachments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.active_storage_attachments_id_seq OWNED BY public.active_storage_attachments.id;


--
-- Name: active_storage_blobs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.active_storage_blobs (
    id bigint NOT NULL,
    key character varying NOT NULL,
    filename character varying NOT NULL,
    content_type character varying,
    metadata text,
    service_name character varying NOT NULL,
    byte_size bigint NOT NULL,
    checksum character varying,
    created_at timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.active_storage_blobs OWNER TO postgres;

--
-- Name: active_storage_blobs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.active_storage_blobs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.active_storage_blobs_id_seq OWNER TO postgres;

--
-- Name: active_storage_blobs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.active_storage_blobs_id_seq OWNED BY public.active_storage_blobs.id;


--
-- Name: active_storage_variant_records; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.active_storage_variant_records (
    id bigint NOT NULL,
    blob_id bigint NOT NULL,
    variation_digest character varying NOT NULL
);


ALTER TABLE public.active_storage_variant_records OWNER TO postgres;

--
-- Name: active_storage_variant_records_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.active_storage_variant_records_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.active_storage_variant_records_id_seq OWNER TO postgres;

--
-- Name: active_storage_variant_records_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.active_storage_variant_records_id_seq OWNED BY public.active_storage_variant_records.id;


--
-- Name: ar_internal_metadata; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ar_internal_metadata (
    key character varying NOT NULL,
    value character varying,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.ar_internal_metadata OWNER TO postgres;

--
-- Name: checkpoint_blobs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.checkpoint_blobs (
    thread_id text NOT NULL,
    checkpoint_ns text DEFAULT ''::text NOT NULL,
    channel text NOT NULL,
    version text NOT NULL,
    type text NOT NULL,
    blob bytea
);


ALTER TABLE public.checkpoint_blobs OWNER TO postgres;

--
-- Name: checkpoint_migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.checkpoint_migrations (
    v integer NOT NULL
);


ALTER TABLE public.checkpoint_migrations OWNER TO postgres;

--
-- Name: checkpoint_writes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.checkpoint_writes (
    thread_id text NOT NULL,
    checkpoint_ns text DEFAULT ''::text NOT NULL,
    checkpoint_id text NOT NULL,
    task_id text NOT NULL,
    idx integer NOT NULL,
    channel text NOT NULL,
    type text,
    blob bytea NOT NULL,
    task_path text DEFAULT ''::text NOT NULL
);


ALTER TABLE public.checkpoint_writes OWNER TO postgres;

--
-- Name: checkpoints; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.checkpoints (
    thread_id text NOT NULL,
    checkpoint_ns text DEFAULT ''::text NOT NULL,
    checkpoint_id text NOT NULL,
    parent_checkpoint_id text,
    type text,
    checkpoint jsonb NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL
);


ALTER TABLE public.checkpoints OWNER TO postgres;

--
-- Name: llama_bot_rails_conversation_participants; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.llama_bot_rails_conversation_participants (
    id bigint NOT NULL,
    conversation_id bigint NOT NULL,
    user_id integer NOT NULL,
    last_read_at timestamp(6) without time zone,
    muted boolean DEFAULT false,
    joined_at timestamp(6) without time zone NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.llama_bot_rails_conversation_participants OWNER TO postgres;

--
-- Name: llama_bot_rails_conversation_participants_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.llama_bot_rails_conversation_participants_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.llama_bot_rails_conversation_participants_id_seq OWNER TO postgres;

--
-- Name: llama_bot_rails_conversation_participants_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.llama_bot_rails_conversation_participants_id_seq OWNED BY public.llama_bot_rails_conversation_participants.id;


--
-- Name: llama_bot_rails_conversations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.llama_bot_rails_conversations (
    id bigint NOT NULL,
    title character varying,
    conversation_type character varying DEFAULT 'direct'::character varying NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.llama_bot_rails_conversations OWNER TO postgres;

--
-- Name: llama_bot_rails_conversations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.llama_bot_rails_conversations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.llama_bot_rails_conversations_id_seq OWNER TO postgres;

--
-- Name: llama_bot_rails_conversations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.llama_bot_rails_conversations_id_seq OWNED BY public.llama_bot_rails_conversations.id;


--
-- Name: llama_bot_rails_direct_messages; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.llama_bot_rails_direct_messages (
    id bigint NOT NULL,
    conversation_id bigint NOT NULL,
    sender_id integer NOT NULL,
    body text NOT NULL,
    edited_at timestamp(6) without time zone,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.llama_bot_rails_direct_messages OWNER TO postgres;

--
-- Name: llama_bot_rails_direct_messages_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.llama_bot_rails_direct_messages_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.llama_bot_rails_direct_messages_id_seq OWNER TO postgres;

--
-- Name: llama_bot_rails_direct_messages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.llama_bot_rails_direct_messages_id_seq OWNED BY public.llama_bot_rails_direct_messages.id;


--
-- Name: llama_bot_rails_feedback_comments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.llama_bot_rails_feedback_comments (
    id bigint NOT NULL,
    commentable_type character varying NOT NULL,
    commentable_id bigint NOT NULL,
    body text NOT NULL,
    user_id integer,
    author_name character varying,
    is_admin_response boolean DEFAULT false,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL,
    parent_id bigint,
    mentioned_user_ids json DEFAULT '[]'::json
);


ALTER TABLE public.llama_bot_rails_feedback_comments OWNER TO postgres;

--
-- Name: llama_bot_rails_feedback_comments_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.llama_bot_rails_feedback_comments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.llama_bot_rails_feedback_comments_id_seq OWNER TO postgres;

--
-- Name: llama_bot_rails_feedback_comments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.llama_bot_rails_feedback_comments_id_seq OWNED BY public.llama_bot_rails_feedback_comments.id;


--
-- Name: llama_bot_rails_notifications; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.llama_bot_rails_notifications (
    id bigint NOT NULL,
    user_id integer NOT NULL,
    actor_id integer,
    notifiable_type character varying NOT NULL,
    notifiable_id bigint NOT NULL,
    notification_type character varying NOT NULL,
    message text,
    read_at timestamp(6) without time zone,
    metadata json,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.llama_bot_rails_notifications OWNER TO postgres;

--
-- Name: llama_bot_rails_notifications_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.llama_bot_rails_notifications_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.llama_bot_rails_notifications_id_seq OWNER TO postgres;

--
-- Name: llama_bot_rails_notifications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.llama_bot_rails_notifications_id_seq OWNED BY public.llama_bot_rails_notifications.id;


--
-- Name: llama_bot_rails_projects; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.llama_bot_rails_projects (
    id bigint NOT NULL,
    name character varying NOT NULL,
    description text,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.llama_bot_rails_projects OWNER TO postgres;

--
-- Name: llama_bot_rails_projects_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.llama_bot_rails_projects_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.llama_bot_rails_projects_id_seq OWNER TO postgres;

--
-- Name: llama_bot_rails_projects_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.llama_bot_rails_projects_id_seq OWNED BY public.llama_bot_rails_projects.id;


--
-- Name: llama_bot_rails_shared_links; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.llama_bot_rails_shared_links (
    id bigint NOT NULL,
    token character varying NOT NULL,
    attachment_id bigint NOT NULL,
    view_count integer DEFAULT 0,
    expires_at timestamp(6) without time zone,
    created_by_id integer,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.llama_bot_rails_shared_links OWNER TO postgres;

--
-- Name: llama_bot_rails_shared_links_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.llama_bot_rails_shared_links_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.llama_bot_rails_shared_links_id_seq OWNER TO postgres;

--
-- Name: llama_bot_rails_shared_links_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.llama_bot_rails_shared_links_id_seq OWNED BY public.llama_bot_rails_shared_links.id;


--
-- Name: llama_bot_rails_taggings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.llama_bot_rails_taggings (
    id bigint NOT NULL,
    tag_id bigint NOT NULL,
    taggable_type character varying NOT NULL,
    taggable_id bigint NOT NULL,
    tagged_by_user_id integer,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.llama_bot_rails_taggings OWNER TO postgres;

--
-- Name: llama_bot_rails_taggings_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.llama_bot_rails_taggings_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.llama_bot_rails_taggings_id_seq OWNER TO postgres;

--
-- Name: llama_bot_rails_taggings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.llama_bot_rails_taggings_id_seq OWNED BY public.llama_bot_rails_taggings.id;


--
-- Name: llama_bot_rails_tags; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.llama_bot_rails_tags (
    id bigint NOT NULL,
    name character varying NOT NULL,
    color character varying DEFAULT '#6366f1'::character varying,
    description text,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.llama_bot_rails_tags OWNER TO postgres;

--
-- Name: llama_bot_rails_tags_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.llama_bot_rails_tags_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.llama_bot_rails_tags_id_seq OWNER TO postgres;

--
-- Name: llama_bot_rails_tags_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.llama_bot_rails_tags_id_seq OWNED BY public.llama_bot_rails_tags.id;


--
-- Name: llama_bot_rails_ticket_comments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.llama_bot_rails_ticket_comments (
    id bigint NOT NULL,
    ticket_id bigint NOT NULL,
    body text NOT NULL,
    user_id integer,
    author_name character varying,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.llama_bot_rails_ticket_comments OWNER TO postgres;

--
-- Name: llama_bot_rails_ticket_comments_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.llama_bot_rails_ticket_comments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.llama_bot_rails_ticket_comments_id_seq OWNER TO postgres;

--
-- Name: llama_bot_rails_ticket_comments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.llama_bot_rails_ticket_comments_id_seq OWNED BY public.llama_bot_rails_ticket_comments.id;


--
-- Name: llama_bot_rails_ticket_traces; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.llama_bot_rails_ticket_traces (
    id bigint NOT NULL,
    ticket_id bigint NOT NULL,
    langsmith_url character varying,
    langsmith_run_id character varying,
    trace_type integer DEFAULT 0,
    tokens_used integer,
    model character varying,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.llama_bot_rails_ticket_traces OWNER TO postgres;

--
-- Name: llama_bot_rails_ticket_traces_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.llama_bot_rails_ticket_traces_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.llama_bot_rails_ticket_traces_id_seq OWNER TO postgres;

--
-- Name: llama_bot_rails_ticket_traces_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.llama_bot_rails_ticket_traces_id_seq OWNED BY public.llama_bot_rails_ticket_traces.id;


--
-- Name: llama_bot_rails_tickets; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.llama_bot_rails_tickets (
    id bigint NOT NULL,
    title character varying NOT NULL,
    description text,
    status character varying DEFAULT 'backlog'::character varying NOT NULL,
    "position" integer,
    notes text,
    agent_result integer,
    agent_notes text,
    langsmith_url character varying,
    ticket_type integer,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL,
    research_notes text,
    tokens_to_create_ticket integer,
    tokens_to_implement_ticket integer,
    llm_model character varying,
    work_started_at timestamp(6) without time zone,
    work_completed_at timestamp(6) without time zone,
    points_estimate integer,
    points_actual numeric(10,2),
    project_id bigint
);


ALTER TABLE public.llama_bot_rails_tickets OWNER TO postgres;

--
-- Name: llama_bot_rails_tickets_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.llama_bot_rails_tickets_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.llama_bot_rails_tickets_id_seq OWNER TO postgres;

--
-- Name: llama_bot_rails_tickets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.llama_bot_rails_tickets_id_seq OWNED BY public.llama_bot_rails_tickets.id;


--
-- Name: llama_bot_rails_user_feedbacks; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.llama_bot_rails_user_feedbacks (
    id bigint NOT NULL,
    title character varying NOT NULL,
    description text,
    feedback_type character varying DEFAULT 'general'::character varying NOT NULL,
    status character varying DEFAULT 'open'::character varying NOT NULL,
    priority integer DEFAULT 0,
    user_id integer NOT NULL,
    user_email character varying,
    admin_notes text,
    resolution character varying,
    resolved_at timestamp(6) without time zone,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.llama_bot_rails_user_feedbacks OWNER TO postgres;

--
-- Name: llama_bot_rails_user_feedbacks_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.llama_bot_rails_user_feedbacks_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.llama_bot_rails_user_feedbacks_id_seq OWNER TO postgres;

--
-- Name: llama_bot_rails_user_feedbacks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.llama_bot_rails_user_feedbacks_id_seq OWNED BY public.llama_bot_rails_user_feedbacks.id;


--
-- Name: llama_bot_rails_user_requests; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.llama_bot_rails_user_requests (
    id bigint NOT NULL,
    title character varying NOT NULL,
    description text,
    request_type character varying DEFAULT 'feature'::character varying NOT NULL,
    status character varying DEFAULT 'submitted'::character varying NOT NULL,
    priority integer DEFAULT 0,
    user_id integer NOT NULL,
    user_email character varying,
    admin_notes text,
    response text,
    responded_at timestamp(6) without time zone,
    votes_count integer DEFAULT 0,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.llama_bot_rails_user_requests OWNER TO postgres;

--
-- Name: llama_bot_rails_user_requests_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.llama_bot_rails_user_requests_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.llama_bot_rails_user_requests_id_seq OWNER TO postgres;

--
-- Name: llama_bot_rails_user_requests_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.llama_bot_rails_user_requests_id_seq OWNED BY public.llama_bot_rails_user_requests.id;


--
-- Name: schema_migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.schema_migrations (
    version character varying NOT NULL
);


ALTER TABLE public.schema_migrations OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id bigint NOT NULL,
    name character varying,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL,
    email character varying DEFAULT ''::character varying NOT NULL,
    encrypted_password character varying DEFAULT ''::character varying NOT NULL,
    reset_password_token character varying,
    reset_password_sent_at timestamp(6) without time zone,
    remember_created_at timestamp(6) without time zone,
    twilio_number character varying,
    admin boolean,
    api_token character varying
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: versions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.versions (
    id bigint NOT NULL,
    item_type character varying NOT NULL,
    item_id bigint NOT NULL,
    event character varying NOT NULL,
    whodunnit character varying,
    object jsonb,
    object_changes jsonb,
    created_at timestamp(6) without time zone
);


ALTER TABLE public.versions OWNER TO postgres;

--
-- Name: versions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.versions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.versions_id_seq OWNER TO postgres;

--
-- Name: versions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.versions_id_seq OWNED BY public.versions.id;


--
-- Name: action_text_rich_texts id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.action_text_rich_texts ALTER COLUMN id SET DEFAULT nextval('public.action_text_rich_texts_id_seq'::regclass);


--
-- Name: active_storage_attachments id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.active_storage_attachments ALTER COLUMN id SET DEFAULT nextval('public.active_storage_attachments_id_seq'::regclass);


--
-- Name: active_storage_blobs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.active_storage_blobs ALTER COLUMN id SET DEFAULT nextval('public.active_storage_blobs_id_seq'::regclass);


--
-- Name: active_storage_variant_records id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.active_storage_variant_records ALTER COLUMN id SET DEFAULT nextval('public.active_storage_variant_records_id_seq'::regclass);


--
-- Name: llama_bot_rails_conversation_participants id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.llama_bot_rails_conversation_participants ALTER COLUMN id SET DEFAULT nextval('public.llama_bot_rails_conversation_participants_id_seq'::regclass);


--
-- Name: llama_bot_rails_conversations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.llama_bot_rails_conversations ALTER COLUMN id SET DEFAULT nextval('public.llama_bot_rails_conversations_id_seq'::regclass);


--
-- Name: llama_bot_rails_direct_messages id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.llama_bot_rails_direct_messages ALTER COLUMN id SET DEFAULT nextval('public.llama_bot_rails_direct_messages_id_seq'::regclass);


--
-- Name: llama_bot_rails_feedback_comments id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.llama_bot_rails_feedback_comments ALTER COLUMN id SET DEFAULT nextval('public.llama_bot_rails_feedback_comments_id_seq'::regclass);


--
-- Name: llama_bot_rails_notifications id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.llama_bot_rails_notifications ALTER COLUMN id SET DEFAULT nextval('public.llama_bot_rails_notifications_id_seq'::regclass);


--
-- Name: llama_bot_rails_projects id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.llama_bot_rails_projects ALTER COLUMN id SET DEFAULT nextval('public.llama_bot_rails_projects_id_seq'::regclass);


--
-- Name: llama_bot_rails_shared_links id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.llama_bot_rails_shared_links ALTER COLUMN id SET DEFAULT nextval('public.llama_bot_rails_shared_links_id_seq'::regclass);


--
-- Name: llama_bot_rails_taggings id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.llama_bot_rails_taggings ALTER COLUMN id SET DEFAULT nextval('public.llama_bot_rails_taggings_id_seq'::regclass);


--
-- Name: llama_bot_rails_tags id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.llama_bot_rails_tags ALTER COLUMN id SET DEFAULT nextval('public.llama_bot_rails_tags_id_seq'::regclass);


--
-- Name: llama_bot_rails_ticket_comments id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.llama_bot_rails_ticket_comments ALTER COLUMN id SET DEFAULT nextval('public.llama_bot_rails_ticket_comments_id_seq'::regclass);


--
-- Name: llama_bot_rails_ticket_traces id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.llama_bot_rails_ticket_traces ALTER COLUMN id SET DEFAULT nextval('public.llama_bot_rails_ticket_traces_id_seq'::regclass);


--
-- Name: llama_bot_rails_tickets id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.llama_bot_rails_tickets ALTER COLUMN id SET DEFAULT nextval('public.llama_bot_rails_tickets_id_seq'::regclass);


--
-- Name: llama_bot_rails_user_feedbacks id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.llama_bot_rails_user_feedbacks ALTER COLUMN id SET DEFAULT nextval('public.llama_bot_rails_user_feedbacks_id_seq'::regclass);


--
-- Name: llama_bot_rails_user_requests id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.llama_bot_rails_user_requests ALTER COLUMN id SET DEFAULT nextval('public.llama_bot_rails_user_requests_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: versions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.versions ALTER COLUMN id SET DEFAULT nextval('public.versions_id_seq'::regclass);


--
-- Data for Name: action_text_rich_texts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.action_text_rich_texts (id, name, body, record_type, record_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: active_storage_attachments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.active_storage_attachments (id, name, record_type, record_id, blob_id, created_at) FROM stdin;
\.


--
-- Data for Name: active_storage_blobs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.active_storage_blobs (id, key, filename, content_type, metadata, service_name, byte_size, checksum, created_at) FROM stdin;
\.


--
-- Data for Name: active_storage_variant_records; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.active_storage_variant_records (id, blob_id, variation_digest) FROM stdin;
\.


--
-- Data for Name: ar_internal_metadata; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ar_internal_metadata (key, value, created_at, updated_at) FROM stdin;
environment	development	2026-03-25 21:19:43.376933	2026-03-25 21:19:43.376939
schema_sha1	152f33381a7e37012a624d6b7147fa002cea04ae	2026-03-25 21:19:43.385325	2026-03-25 21:19:43.385329
\.


--
-- Data for Name: checkpoint_blobs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.checkpoint_blobs (thread_id, checkpoint_ns, channel, version, type, blob) FROM stdin;
\.


--
-- Data for Name: checkpoint_migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.checkpoint_migrations (v) FROM stdin;
0
1
2
3
4
5
6
7
8
9
\.


--
-- Data for Name: checkpoint_writes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.checkpoint_writes (thread_id, checkpoint_ns, checkpoint_id, task_id, idx, channel, type, blob, task_path) FROM stdin;
\.


--
-- Data for Name: checkpoints; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.checkpoints (thread_id, checkpoint_ns, checkpoint_id, parent_checkpoint_id, type, checkpoint, metadata) FROM stdin;
\.


--
-- Data for Name: llama_bot_rails_conversation_participants; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.llama_bot_rails_conversation_participants (id, conversation_id, user_id, last_read_at, muted, joined_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: llama_bot_rails_conversations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.llama_bot_rails_conversations (id, title, conversation_type, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: llama_bot_rails_direct_messages; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.llama_bot_rails_direct_messages (id, conversation_id, sender_id, body, edited_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: llama_bot_rails_feedback_comments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.llama_bot_rails_feedback_comments (id, commentable_type, commentable_id, body, user_id, author_name, is_admin_response, created_at, updated_at, parent_id, mentioned_user_ids) FROM stdin;
\.


--
-- Data for Name: llama_bot_rails_notifications; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.llama_bot_rails_notifications (id, user_id, actor_id, notifiable_type, notifiable_id, notification_type, message, read_at, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: llama_bot_rails_projects; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.llama_bot_rails_projects (id, name, description, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: llama_bot_rails_shared_links; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.llama_bot_rails_shared_links (id, token, attachment_id, view_count, expires_at, created_by_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: llama_bot_rails_taggings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.llama_bot_rails_taggings (id, tag_id, taggable_type, taggable_id, tagged_by_user_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: llama_bot_rails_tags; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.llama_bot_rails_tags (id, name, color, description, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: llama_bot_rails_ticket_comments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.llama_bot_rails_ticket_comments (id, ticket_id, body, user_id, author_name, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: llama_bot_rails_ticket_traces; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.llama_bot_rails_ticket_traces (id, ticket_id, langsmith_url, langsmith_run_id, trace_type, tokens_used, model, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: llama_bot_rails_tickets; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.llama_bot_rails_tickets (id, title, description, status, "position", notes, agent_result, agent_notes, langsmith_url, ticket_type, created_at, updated_at, research_notes, tokens_to_create_ticket, tokens_to_implement_ticket, llm_model, work_started_at, work_completed_at, points_estimate, points_actual, project_id) FROM stdin;
\.


--
-- Data for Name: llama_bot_rails_user_feedbacks; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.llama_bot_rails_user_feedbacks (id, title, description, feedback_type, status, priority, user_id, user_email, admin_notes, resolution, resolved_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: llama_bot_rails_user_requests; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.llama_bot_rails_user_requests (id, title, description, request_type, status, priority, user_id, user_email, admin_notes, response, responded_at, votes_count, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.schema_migrations (version) FROM stdin;
20260125190610
20260125184728
20251009025833
20251003023243
20250904023026
20250904022936
20250902153145
20250821003540
20250821003523
20260208210542
20260208210543
20260208210544
20260208210545
20260213031528
20260213031529
20260213031530
20260213031531
20260213031532
20260213031533
20260213184800
20260306122643
20260316224450
20260316224451
20260316224452
20260316224453
20260320134720
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, name, created_at, updated_at, email, encrypted_password, reset_password_token, reset_password_sent_at, remember_created_at, twilio_number, admin, api_token) FROM stdin;
1	\N	2026-03-25 21:19:44.524218	2026-03-25 21:19:44.524218	kody@llamapress.ai	$2a$12$aMFqhldxjkX7s3sqQ8ZGEuDRPeC4sMAIA/.XBZ6wM9dUfNYLYkEeS	\N	\N	\N	\N	\N	5a359aa0b3419ab6a165822ee24d2706e26a8464e4e229bf1639c196098b0ab2
\.


--
-- Data for Name: versions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.versions (id, item_type, item_id, event, whodunnit, object, object_changes, created_at) FROM stdin;
\.


--
-- Name: action_text_rich_texts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.action_text_rich_texts_id_seq', 1, false);


--
-- Name: active_storage_attachments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.active_storage_attachments_id_seq', 1, false);


--
-- Name: active_storage_blobs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.active_storage_blobs_id_seq', 1, false);


--
-- Name: active_storage_variant_records_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.active_storage_variant_records_id_seq', 1, false);


--
-- Name: llama_bot_rails_conversation_participants_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.llama_bot_rails_conversation_participants_id_seq', 1, false);


--
-- Name: llama_bot_rails_conversations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.llama_bot_rails_conversations_id_seq', 1, false);


--
-- Name: llama_bot_rails_direct_messages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.llama_bot_rails_direct_messages_id_seq', 1, false);


--
-- Name: llama_bot_rails_feedback_comments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.llama_bot_rails_feedback_comments_id_seq', 1, false);


--
-- Name: llama_bot_rails_notifications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.llama_bot_rails_notifications_id_seq', 1, false);


--
-- Name: llama_bot_rails_projects_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.llama_bot_rails_projects_id_seq', 1, false);


--
-- Name: llama_bot_rails_shared_links_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.llama_bot_rails_shared_links_id_seq', 1, false);


--
-- Name: llama_bot_rails_taggings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.llama_bot_rails_taggings_id_seq', 1, false);


--
-- Name: llama_bot_rails_tags_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.llama_bot_rails_tags_id_seq', 1, false);


--
-- Name: llama_bot_rails_ticket_comments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.llama_bot_rails_ticket_comments_id_seq', 1, false);


--
-- Name: llama_bot_rails_ticket_traces_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.llama_bot_rails_ticket_traces_id_seq', 1, false);


--
-- Name: llama_bot_rails_tickets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.llama_bot_rails_tickets_id_seq', 1, false);


--
-- Name: llama_bot_rails_user_feedbacks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.llama_bot_rails_user_feedbacks_id_seq', 1, false);


--
-- Name: llama_bot_rails_user_requests_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.llama_bot_rails_user_requests_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_seq', 1, true);


--
-- Name: versions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.versions_id_seq', 1, false);


--
-- Name: action_text_rich_texts action_text_rich_texts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.action_text_rich_texts
    ADD CONSTRAINT action_text_rich_texts_pkey PRIMARY KEY (id);


--
-- Name: active_storage_attachments active_storage_attachments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.active_storage_attachments
    ADD CONSTRAINT active_storage_attachments_pkey PRIMARY KEY (id);


--
-- Name: active_storage_blobs active_storage_blobs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.active_storage_blobs
    ADD CONSTRAINT active_storage_blobs_pkey PRIMARY KEY (id);


--
-- Name: active_storage_variant_records active_storage_variant_records_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.active_storage_variant_records
    ADD CONSTRAINT active_storage_variant_records_pkey PRIMARY KEY (id);


--
-- Name: ar_internal_metadata ar_internal_metadata_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ar_internal_metadata
    ADD CONSTRAINT ar_internal_metadata_pkey PRIMARY KEY (key);


--
-- Name: checkpoint_blobs checkpoint_blobs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.checkpoint_blobs
    ADD CONSTRAINT checkpoint_blobs_pkey PRIMARY KEY (thread_id, checkpoint_ns, channel, version);


--
-- Name: checkpoint_migrations checkpoint_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.checkpoint_migrations
    ADD CONSTRAINT checkpoint_migrations_pkey PRIMARY KEY (v);


--
-- Name: checkpoint_writes checkpoint_writes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.checkpoint_writes
    ADD CONSTRAINT checkpoint_writes_pkey PRIMARY KEY (thread_id, checkpoint_ns, checkpoint_id, task_id, idx);


--
-- Name: checkpoints checkpoints_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.checkpoints
    ADD CONSTRAINT checkpoints_pkey PRIMARY KEY (thread_id, checkpoint_ns, checkpoint_id);


--
-- Name: llama_bot_rails_conversation_participants llama_bot_rails_conversation_participants_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.llama_bot_rails_conversation_participants
    ADD CONSTRAINT llama_bot_rails_conversation_participants_pkey PRIMARY KEY (id);


--
-- Name: llama_bot_rails_conversations llama_bot_rails_conversations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.llama_bot_rails_conversations
    ADD CONSTRAINT llama_bot_rails_conversations_pkey PRIMARY KEY (id);


--
-- Name: llama_bot_rails_direct_messages llama_bot_rails_direct_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.llama_bot_rails_direct_messages
    ADD CONSTRAINT llama_bot_rails_direct_messages_pkey PRIMARY KEY (id);


--
-- Name: llama_bot_rails_feedback_comments llama_bot_rails_feedback_comments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.llama_bot_rails_feedback_comments
    ADD CONSTRAINT llama_bot_rails_feedback_comments_pkey PRIMARY KEY (id);


--
-- Name: llama_bot_rails_notifications llama_bot_rails_notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.llama_bot_rails_notifications
    ADD CONSTRAINT llama_bot_rails_notifications_pkey PRIMARY KEY (id);


--
-- Name: llama_bot_rails_projects llama_bot_rails_projects_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.llama_bot_rails_projects
    ADD CONSTRAINT llama_bot_rails_projects_pkey PRIMARY KEY (id);


--
-- Name: llama_bot_rails_shared_links llama_bot_rails_shared_links_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.llama_bot_rails_shared_links
    ADD CONSTRAINT llama_bot_rails_shared_links_pkey PRIMARY KEY (id);


--
-- Name: llama_bot_rails_taggings llama_bot_rails_taggings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.llama_bot_rails_taggings
    ADD CONSTRAINT llama_bot_rails_taggings_pkey PRIMARY KEY (id);


--
-- Name: llama_bot_rails_tags llama_bot_rails_tags_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.llama_bot_rails_tags
    ADD CONSTRAINT llama_bot_rails_tags_pkey PRIMARY KEY (id);


--
-- Name: llama_bot_rails_ticket_comments llama_bot_rails_ticket_comments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.llama_bot_rails_ticket_comments
    ADD CONSTRAINT llama_bot_rails_ticket_comments_pkey PRIMARY KEY (id);


--
-- Name: llama_bot_rails_ticket_traces llama_bot_rails_ticket_traces_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.llama_bot_rails_ticket_traces
    ADD CONSTRAINT llama_bot_rails_ticket_traces_pkey PRIMARY KEY (id);


--
-- Name: llama_bot_rails_tickets llama_bot_rails_tickets_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.llama_bot_rails_tickets
    ADD CONSTRAINT llama_bot_rails_tickets_pkey PRIMARY KEY (id);


--
-- Name: llama_bot_rails_user_feedbacks llama_bot_rails_user_feedbacks_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.llama_bot_rails_user_feedbacks
    ADD CONSTRAINT llama_bot_rails_user_feedbacks_pkey PRIMARY KEY (id);


--
-- Name: llama_bot_rails_user_requests llama_bot_rails_user_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.llama_bot_rails_user_requests
    ADD CONSTRAINT llama_bot_rails_user_requests_pkey PRIMARY KEY (id);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: versions versions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.versions
    ADD CONSTRAINT versions_pkey PRIMARY KEY (id);


--
-- Name: checkpoint_blobs_thread_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX checkpoint_blobs_thread_id_idx ON public.checkpoint_blobs USING btree (thread_id);


--
-- Name: checkpoint_writes_thread_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX checkpoint_writes_thread_id_idx ON public.checkpoint_writes USING btree (thread_id);


--
-- Name: checkpoints_thread_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX checkpoints_thread_id_idx ON public.checkpoints USING btree (thread_id);


--
-- Name: idx_conv_participants_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX idx_conv_participants_unique ON public.llama_bot_rails_conversation_participants USING btree (conversation_id, user_id);


--
-- Name: idx_dm_conversation_timeline; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_dm_conversation_timeline ON public.llama_bot_rails_direct_messages USING btree (conversation_id, created_at);


--
-- Name: idx_notifications_notifiable; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_notifications_notifiable ON public.llama_bot_rails_notifications USING btree (notifiable_type, notifiable_id);


--
-- Name: idx_notifications_user_unread; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_notifications_user_unread ON public.llama_bot_rails_notifications USING btree (user_id, read_at);


--
-- Name: idx_on_conversation_id_2fa0ba1b29; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_on_conversation_id_2fa0ba1b29 ON public.llama_bot_rails_conversation_participants USING btree (conversation_id);


--
-- Name: idx_on_last_read_at_4f0fd5067a; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_on_last_read_at_4f0fd5067a ON public.llama_bot_rails_conversation_participants USING btree (last_read_at);


--
-- Name: index_action_text_rich_texts_uniqueness; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX index_action_text_rich_texts_uniqueness ON public.action_text_rich_texts USING btree (record_type, record_id, name);


--
-- Name: index_active_storage_attachments_on_blob_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_active_storage_attachments_on_blob_id ON public.active_storage_attachments USING btree (blob_id);


--
-- Name: index_active_storage_attachments_uniqueness; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX index_active_storage_attachments_uniqueness ON public.active_storage_attachments USING btree (record_type, record_id, name, blob_id);


--
-- Name: index_active_storage_blobs_on_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX index_active_storage_blobs_on_key ON public.active_storage_blobs USING btree (key);


--
-- Name: index_active_storage_variant_records_uniqueness; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX index_active_storage_variant_records_uniqueness ON public.active_storage_variant_records USING btree (blob_id, variation_digest);


--
-- Name: index_feedback_comments_on_commentable; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_feedback_comments_on_commentable ON public.llama_bot_rails_feedback_comments USING btree (commentable_type, commentable_id);


--
-- Name: index_llama_bot_rails_conversation_participants_on_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_llama_bot_rails_conversation_participants_on_user_id ON public.llama_bot_rails_conversation_participants USING btree (user_id);


--
-- Name: index_llama_bot_rails_conversations_on_conversation_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_llama_bot_rails_conversations_on_conversation_type ON public.llama_bot_rails_conversations USING btree (conversation_type);


--
-- Name: index_llama_bot_rails_conversations_on_updated_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_llama_bot_rails_conversations_on_updated_at ON public.llama_bot_rails_conversations USING btree (updated_at);


--
-- Name: index_llama_bot_rails_direct_messages_on_conversation_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_llama_bot_rails_direct_messages_on_conversation_id ON public.llama_bot_rails_direct_messages USING btree (conversation_id);


--
-- Name: index_llama_bot_rails_direct_messages_on_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_llama_bot_rails_direct_messages_on_created_at ON public.llama_bot_rails_direct_messages USING btree (created_at);


--
-- Name: index_llama_bot_rails_direct_messages_on_sender_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_llama_bot_rails_direct_messages_on_sender_id ON public.llama_bot_rails_direct_messages USING btree (sender_id);


--
-- Name: index_llama_bot_rails_feedback_comments_on_commentable; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_llama_bot_rails_feedback_comments_on_commentable ON public.llama_bot_rails_feedback_comments USING btree (commentable_type, commentable_id);


--
-- Name: index_llama_bot_rails_feedback_comments_on_parent_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_llama_bot_rails_feedback_comments_on_parent_id ON public.llama_bot_rails_feedback_comments USING btree (parent_id);


--
-- Name: index_llama_bot_rails_feedback_comments_on_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_llama_bot_rails_feedback_comments_on_user_id ON public.llama_bot_rails_feedback_comments USING btree (user_id);


--
-- Name: index_llama_bot_rails_notifications_on_actor_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_llama_bot_rails_notifications_on_actor_id ON public.llama_bot_rails_notifications USING btree (actor_id);


--
-- Name: index_llama_bot_rails_notifications_on_notifiable; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_llama_bot_rails_notifications_on_notifiable ON public.llama_bot_rails_notifications USING btree (notifiable_type, notifiable_id);


--
-- Name: index_llama_bot_rails_notifications_on_notification_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_llama_bot_rails_notifications_on_notification_type ON public.llama_bot_rails_notifications USING btree (notification_type);


--
-- Name: index_llama_bot_rails_notifications_on_read_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_llama_bot_rails_notifications_on_read_at ON public.llama_bot_rails_notifications USING btree (read_at);


--
-- Name: index_llama_bot_rails_notifications_on_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_llama_bot_rails_notifications_on_user_id ON public.llama_bot_rails_notifications USING btree (user_id);


--
-- Name: index_llama_bot_rails_projects_on_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_llama_bot_rails_projects_on_name ON public.llama_bot_rails_projects USING btree (name);


--
-- Name: index_llama_bot_rails_shared_links_on_attachment_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_llama_bot_rails_shared_links_on_attachment_id ON public.llama_bot_rails_shared_links USING btree (attachment_id);


--
-- Name: index_llama_bot_rails_shared_links_on_token; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX index_llama_bot_rails_shared_links_on_token ON public.llama_bot_rails_shared_links USING btree (token);


--
-- Name: index_llama_bot_rails_taggings_on_tag_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_llama_bot_rails_taggings_on_tag_id ON public.llama_bot_rails_taggings USING btree (tag_id);


--
-- Name: index_llama_bot_rails_taggings_on_taggable; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_llama_bot_rails_taggings_on_taggable ON public.llama_bot_rails_taggings USING btree (taggable_type, taggable_id);


--
-- Name: index_llama_bot_rails_tags_on_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX index_llama_bot_rails_tags_on_name ON public.llama_bot_rails_tags USING btree (name);


--
-- Name: index_llama_bot_rails_ticket_comments_on_ticket_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_llama_bot_rails_ticket_comments_on_ticket_id ON public.llama_bot_rails_ticket_comments USING btree (ticket_id);


--
-- Name: index_llama_bot_rails_ticket_comments_on_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_llama_bot_rails_ticket_comments_on_user_id ON public.llama_bot_rails_ticket_comments USING btree (user_id);


--
-- Name: index_llama_bot_rails_ticket_traces_on_langsmith_run_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_llama_bot_rails_ticket_traces_on_langsmith_run_id ON public.llama_bot_rails_ticket_traces USING btree (langsmith_run_id);


--
-- Name: index_llama_bot_rails_ticket_traces_on_ticket_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_llama_bot_rails_ticket_traces_on_ticket_id ON public.llama_bot_rails_ticket_traces USING btree (ticket_id);


--
-- Name: index_llama_bot_rails_ticket_traces_on_trace_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_llama_bot_rails_ticket_traces_on_trace_type ON public.llama_bot_rails_ticket_traces USING btree (trace_type);


--
-- Name: index_llama_bot_rails_tickets_on_llm_model; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_llama_bot_rails_tickets_on_llm_model ON public.llama_bot_rails_tickets USING btree (llm_model);


--
-- Name: index_llama_bot_rails_tickets_on_position; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_llama_bot_rails_tickets_on_position ON public.llama_bot_rails_tickets USING btree ("position");


--
-- Name: index_llama_bot_rails_tickets_on_project_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_llama_bot_rails_tickets_on_project_id ON public.llama_bot_rails_tickets USING btree (project_id);


--
-- Name: index_llama_bot_rails_tickets_on_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_llama_bot_rails_tickets_on_status ON public.llama_bot_rails_tickets USING btree (status);


--
-- Name: index_llama_bot_rails_tickets_on_work_completed_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_llama_bot_rails_tickets_on_work_completed_at ON public.llama_bot_rails_tickets USING btree (work_completed_at);


--
-- Name: index_llama_bot_rails_tickets_on_work_started_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_llama_bot_rails_tickets_on_work_started_at ON public.llama_bot_rails_tickets USING btree (work_started_at);


--
-- Name: index_llama_bot_rails_user_feedbacks_on_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_llama_bot_rails_user_feedbacks_on_created_at ON public.llama_bot_rails_user_feedbacks USING btree (created_at);


--
-- Name: index_llama_bot_rails_user_feedbacks_on_feedback_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_llama_bot_rails_user_feedbacks_on_feedback_type ON public.llama_bot_rails_user_feedbacks USING btree (feedback_type);


--
-- Name: index_llama_bot_rails_user_feedbacks_on_priority; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_llama_bot_rails_user_feedbacks_on_priority ON public.llama_bot_rails_user_feedbacks USING btree (priority);


--
-- Name: index_llama_bot_rails_user_feedbacks_on_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_llama_bot_rails_user_feedbacks_on_status ON public.llama_bot_rails_user_feedbacks USING btree (status);


--
-- Name: index_llama_bot_rails_user_feedbacks_on_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_llama_bot_rails_user_feedbacks_on_user_id ON public.llama_bot_rails_user_feedbacks USING btree (user_id);


--
-- Name: index_llama_bot_rails_user_requests_on_priority; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_llama_bot_rails_user_requests_on_priority ON public.llama_bot_rails_user_requests USING btree (priority);


--
-- Name: index_llama_bot_rails_user_requests_on_request_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_llama_bot_rails_user_requests_on_request_type ON public.llama_bot_rails_user_requests USING btree (request_type);


--
-- Name: index_llama_bot_rails_user_requests_on_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_llama_bot_rails_user_requests_on_status ON public.llama_bot_rails_user_requests USING btree (status);


--
-- Name: index_llama_bot_rails_user_requests_on_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_llama_bot_rails_user_requests_on_user_id ON public.llama_bot_rails_user_requests USING btree (user_id);


--
-- Name: index_llama_bot_rails_user_requests_on_votes_count; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_llama_bot_rails_user_requests_on_votes_count ON public.llama_bot_rails_user_requests USING btree (votes_count);


--
-- Name: index_taggings_on_taggable_and_tag; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX index_taggings_on_taggable_and_tag ON public.llama_bot_rails_taggings USING btree (taggable_type, taggable_id, tag_id);


--
-- Name: index_users_on_api_token; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX index_users_on_api_token ON public.users USING btree (api_token);


--
-- Name: index_users_on_email; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX index_users_on_email ON public.users USING btree (email);


--
-- Name: index_users_on_reset_password_token; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX index_users_on_reset_password_token ON public.users USING btree (reset_password_token);


--
-- Name: index_versions_on_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_versions_on_created_at ON public.versions USING btree (created_at);


--
-- Name: index_versions_on_item_type_and_item_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_versions_on_item_type_and_item_id ON public.versions USING btree (item_type, item_id);


--
-- Name: llama_bot_rails_direct_messages fk_rails_6a53f9f831; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.llama_bot_rails_direct_messages
    ADD CONSTRAINT fk_rails_6a53f9f831 FOREIGN KEY (conversation_id) REFERENCES public.llama_bot_rails_conversations(id);


--
-- Name: active_storage_variant_records fk_rails_993965df05; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.active_storage_variant_records
    ADD CONSTRAINT fk_rails_993965df05 FOREIGN KEY (blob_id) REFERENCES public.active_storage_blobs(id);


--
-- Name: llama_bot_rails_tickets fk_rails_a1a7fde936; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.llama_bot_rails_tickets
    ADD CONSTRAINT fk_rails_a1a7fde936 FOREIGN KEY (project_id) REFERENCES public.llama_bot_rails_projects(id);


--
-- Name: llama_bot_rails_ticket_traces fk_rails_ac8024889a; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.llama_bot_rails_ticket_traces
    ADD CONSTRAINT fk_rails_ac8024889a FOREIGN KEY (ticket_id) REFERENCES public.llama_bot_rails_tickets(id);


--
-- Name: llama_bot_rails_taggings fk_rails_b05b275d26; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.llama_bot_rails_taggings
    ADD CONSTRAINT fk_rails_b05b275d26 FOREIGN KEY (tag_id) REFERENCES public.llama_bot_rails_tags(id);


--
-- Name: llama_bot_rails_conversation_participants fk_rails_b085733b9f; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.llama_bot_rails_conversation_participants
    ADD CONSTRAINT fk_rails_b085733b9f FOREIGN KEY (conversation_id) REFERENCES public.llama_bot_rails_conversations(id);


--
-- Name: active_storage_attachments fk_rails_c3b3935057; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.active_storage_attachments
    ADD CONSTRAINT fk_rails_c3b3935057 FOREIGN KEY (blob_id) REFERENCES public.active_storage_blobs(id);


--
-- Name: llama_bot_rails_shared_links fk_rails_e15945295e; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.llama_bot_rails_shared_links
    ADD CONSTRAINT fk_rails_e15945295e FOREIGN KEY (attachment_id) REFERENCES public.active_storage_attachments(id) ON DELETE CASCADE;


--
-- Name: llama_bot_rails_ticket_comments fk_rails_f7d844d7d3; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.llama_bot_rails_ticket_comments
    ADD CONSTRAINT fk_rails_f7d844d7d3 FOREIGN KEY (ticket_id) REFERENCES public.llama_bot_rails_tickets(id);


--
-- Name: llama_bot_rails_feedback_comments fk_rails_fe81bf40ab; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.llama_bot_rails_feedback_comments
    ADD CONSTRAINT fk_rails_fe81bf40ab FOREIGN KEY (parent_id) REFERENCES public.llama_bot_rails_feedback_comments(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict Yin8Vo3QZBIzTWD2PeicHYlzUcvLq1irhCjuMJD3a64tP4P7v8eQPiYkK3f2FZv

